"use client";

// Social icon SVGs — inline to avoid extra deps
const SocialIcons = [
  {
    label: "Facebook",
    color: "#1877F2",
    href: "#",
    svg: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
      </svg>
    ),
  },
  {
    label: "Twitter / X",
    color: "#1DA1F2",
    href: "#",
    svg: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
      </svg>
    ),
  },
  {
    label: "YouTube",
    color: "#FF0000",
    href: "#",
    svg: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
      </svg>
    ),
  },
  {
    label: "Instagram",
    color: "#E1306C",
    href: "#",
    svg: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
      </svg>
    ),
  },
  {
    label: "Pinterest",
    color: "#BD081C",
    href: "#",
    svg: (
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0C5.373 0 0 5.373 0 12c0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738a.36.36 0 01.083.345l-.333 1.36c-.053.22-.174.267-.402.161-1.499-.698-2.436-2.889-2.436-4.649 0-3.785 2.75-7.262 7.929-7.262 4.163 0 7.398 2.967 7.398 6.931 0 4.136-2.607 7.464-6.227 7.464-1.216 0-2.359-.632-2.75-1.378l-.748 2.853c-.271 1.043-1.002 2.35-1.492 3.146C9.57 23.812 10.763 24 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0z"/>
      </svg>
    ),
  },
];

export default function Footer() {
  return (
    <footer>
      {/* SEO text block — white bg, matches original */}
      <div className="bg-white py-14 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-heading font-black text-gray-800 text-base md:text-lg uppercase mb-5">
            NanoVista Africa — Indestructible and Flexible Children's Glasses
          </h2>
          <p className="font-body text-sm text-gray-500 leading-relaxed">
            We know that children are restless by nature. They run, jump, play, and need glasses that
            adapt to them and resist all possible blows and falls they may experience. In NanoVista Africa,
            we bring the best indestructible and flexible children's glasses to Nigeria and West Africa.
            Many parents have opted for NanoVista glasses. They know their toughness and greatly value
            not having to replace their children's glasses every few months. All our glasses are safe,
            manufactured from the best materials, and come in multiple models so that you can always find
            glasses that fit your child's style and taste.
          </p>
        </div>
      </div>

      {/* Main footer — light grey */}
      <div style={{ background: "#f4f4f4" }} className="px-6 py-12">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">

          {/* Legal */}
          <div>
            <h4
              className="font-heading font-bold text-xs tracking-widest uppercase pb-3 mb-4 border-b"
              style={{ color: "#8dc63f", borderColor: "#8dc63f" }}
            >
              Legal Information
            </h4>
            <ul className="space-y-2">
              {["Legal Disclaimer", "Privacy Policy", "Cookies Policy (UE)"].map((l) => (
                <li key={l}>
                  <a
                    href="#"
                    className="font-body text-sm text-gray-600 hover:text-[#8dc63f] transition-colors"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4
              className="font-heading font-bold text-xs tracking-widest uppercase pb-3 mb-4 border-b"
              style={{ color: "#8dc63f", borderColor: "#8dc63f" }}
            >
              Contact
            </h4>
            <ul className="space-y-3 text-sm font-body text-gray-600">
              <li>
                <a
                  href="/become-a-stockist"
                  className="font-heading font-semibold text-xs uppercase tracking-wide hover:text-[#8dc63f] transition-colors"
                  style={{ color: "#8dc63f" }}
                >
                  Are you an optician or distributor?
                </a>
              </li>
              <li>
                <a href="tel:+2348000626684" className="hover:text-[#8dc63f] transition-colors">
                  +234 800 NANOVISTA
                </a>
              </li>
              <li>
                <a href="mailto:info@nanovista.africa" className="hover:text-[#8dc63f] transition-colors">
                  info@nanovista.africa
                </a>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4
              className="font-heading font-bold text-xs tracking-widest uppercase pb-3 mb-4 border-b"
              style={{ color: "#8dc63f", borderColor: "#8dc63f" }}
            >
              Follow Us
            </h4>
            <div className="flex gap-3 flex-wrap">
              {SocialIcons.map((icon) => (
                <a
                  key={icon.label}
                  href={icon.href}
                  aria-label={icon.label}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-white transition-transform hover:scale-110"
                  style={{ background: icon.color }}
                >
                  {icon.svg}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Copyright bar — dark grey strip */}
      <div style={{ background: "#888888" }} className="py-3 px-6 text-center">
        <p className="font-body text-white text-xs">
          Copyright &copy; {new Date().getFullYear()} NanoVista Africa &mdash; Official West Africa Franchise of NanoVista Spain
        </p>
      </div>
    </footer>
  );
}
